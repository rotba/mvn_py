*How to create Eclispe project for Checkstyle and run Unit Tests:

Note: make sure that "M2E - Maven Integration for Eclipse" plugin is installed in your Eclipse.

1) In Eclipse, do "Import ..." > "Maven / Existing Maven Project".
If some additional plugins needto be installed , please install them.

2) In "checkstyle" project, select folder "src/test/java" do right mouse click, select "Run As" > "JUnit Test".