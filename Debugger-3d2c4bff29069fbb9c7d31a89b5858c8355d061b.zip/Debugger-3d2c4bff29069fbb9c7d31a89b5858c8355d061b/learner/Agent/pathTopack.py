__author__ = 'amir'

project="eclipse"

def pathToPack(path):
    return path.replace("/","\\")
