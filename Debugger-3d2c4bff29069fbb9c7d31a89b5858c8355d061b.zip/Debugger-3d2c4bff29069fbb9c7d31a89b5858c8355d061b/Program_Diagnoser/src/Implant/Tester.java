package Implant;

import java.io.IOException;

public class Tester {
	public static void main(String[] args) throws IOException, InterruptedException{
//		TestsRunner.run_from_remote("org.apache.commons.math3.util.FastMathTest.testSinhAccuracy,true");
//		TestsRunner.run_from_remote("org.apache.commons.math3.util.FastMathTest.testSinhAccuracy,false");
		TestsRunner.run_from_remote();
	}
}
